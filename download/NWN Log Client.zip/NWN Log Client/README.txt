# NWN Log Client

This client monitors your Neverwinter Nights log file and sends updates to a remote server for chat integration.

## Setup Instructions

### Installation

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Edit `config.ini` to set your correct NWN log file path and server settings.

3. Run the client:
   ```
   python nwn_log_client.py
   ```

4. Or build an executable:
   ```
   python build_client.py
   ```

### Configuration Options

Edit `config.ini` to configure the following:

- `SERVER_URL`: The base URL of the log server
- `API_ENDPOINT`: The API endpoint for HTTP requests
- `WEBSOCKET_URL`: WebSocket URL for real-time communication
- `NWN_LOG_PATH`: Path to your Neverwinter Nights log file
- `CHECK_INTERVAL`: How often to check for updates (in seconds)
- `CLIENT_NAME`: Name to identify this client to the server

## Testing the Server Connection

You can run the included test server to verify client connectivity:

```
python test_server.py
```

Then set `SERVER_URL` in your config.ini to `http://localhost:5000/` and run the client.
Visit http://localhost:5000/ in your browser to see incoming logs.

## Troubleshooting

If the server is receiving logs but they're not showing in the web frontend:

1. Check the payload format being sent by examining the logs
2. Verify that the frontend is correctly subscribing to the backend events
3. Test with the included test server to isolate client vs. server issues
4. Ensure logs are formatted correctly for the server
5. Check browser console for JavaScript errors in the frontend

Log files are stored in the `logs` directory and contain detailed information
about client operations and any errors encountered. 